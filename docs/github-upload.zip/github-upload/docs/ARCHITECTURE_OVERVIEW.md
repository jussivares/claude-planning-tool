# ARCHITECTURE_OVERVIEW

> **Versio:** 1.0  
> **Päivitetty:** 2025-11-25  
> **Tiedosto:** v1.0_ARCHITECTURE_OVERVIEW.md  
> **Projekti:** Claude API -suunnittelutyökalu  
> **Tarkoitus:** Tekninen arkkitehtuuri ja komponenttirakenne

---

## Arkkitehtuurin perusperiaatteet

### 1. API-First

Suora yhteys Claude API:in, ei välikäsiä. Mahdollistaa 1M token kontekstin ja täyden hallinnan.

```
┌─────────────────────────────────────────────────────────────────────┐
│                      ARKKITEHTUURIPERIAATE                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│   claude.ai                        OMA TYÖKALU                     │
│                                                                     │
│   ┌─────────────────┐              ┌─────────────────┐             │
│   │   Web UI        │              │   Web UI        │             │
│   │   (rajoitettu)  │              │   (oma)         │             │
│   └────────┬────────┘              └────────┬────────┘             │
│            │                                │                       │
│            ▼                                ▼                       │
│   ┌─────────────────┐              ┌─────────────────┐             │
│   │  Anthropic      │              │   OMA BACKEND   │             │
│   │  Backend        │              │   (FastAPI)     │             │
│   │  (black box)    │              └────────┬────────┘             │
│   └────────┬────────┘                       │                       │
│            │                                ▼                       │
│            ▼                       ┌─────────────────┐             │
│   ┌─────────────────┐              │   Claude API    │             │
│   │   Claude API    │              │   (1M konteksti)│             │
│   │  (200K konteksti)│             └─────────────────┘             │
│   └─────────────────┘                                              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 2. Ulkoinen muisti

Tieto säilyy sessioiden välillä, ei katoa kun konteksti täyttyy.

### 3. Läpinäkyvyys

Token-käyttö, kustannukset ja kontekstin sisältö näkyvissä käyttäjälle.

### 4. Modulaarisuus (Black Box -periaate)

Jokainen komponentti on **musta laatikko**:
- **Clean API** - dokumentoitu rajapinta ulkoiseen käyttöön
- **Hidden implementation** - sisäiset yksityiskohdat piilossa
- **Replaceable** - voi kirjoittaa uudelleen pelkän API:n perusteella
- **One owner** - yksi henkilö voi ymmärtää koko moduulin

---

## Primitiivit (Järjestelmän perusyksiköt)

> "Primitiivi on järjestelmän atomi - kaikki rakentuu siitä."

### Tunnistetut primitiivit

| Primitiivi | Kuvaus | Käyttö |
|------------|--------|--------|
| **Message** | Yksittäinen viesti keskustelussa | Chat-historia, konteksti |
| **MemoryItem** | Muistiin tallennettu tieto | Päätökset, yhteenvedot, dokumentit |
| **Session** | Kokonainen suunnittelusessio | Tallennus, lataus, jatkaminen |

### Message (Chat-primitiivi)

```python
Message {
    role: "user" | "assistant" | "system"
    content: str | List[ContentBlock]
    timestamp: datetime
    tokens: int
    metadata: {
        model: str
        effort: str | None
        cost_usd: float
    }
}
```

**Operaatiot:**
- Create (käyttäjä/Claude luo)
- Read (näytä UI:ssa)
- Count tokens (kontekstin hallinta)
- Summarize (tiivistä kun konteksti täyttyy)

### MemoryItem (Muisti-primitiivi)

```python
MemoryItem {
    path: str                    # esim. "decisions/backend.md"
    type: "decision" | "summary" | "spec" | "note"
    content: str                 # Markdown
    created_at: datetime
    updated_at: datetime
    tags: List[str]
}
```

**Operaatiot:**
- Create / Update / Delete
- Read (lataa kontekstiin)
- List (hae hakemistosta)
- Search (hae sisällöstä)

### Session (Sessio-primitiivi)

```python
Session {
    id: uuid
    name: str
    project_id: uuid
    messages: List[Message]
    active_memory: List[str]     # Ladatut muistitiedostot
    active_files: List[str]      # Ladatut projektitiedostot
    model: str
    total_tokens: int
    total_cost_usd: float
    created_at: datetime
    updated_at: datetime
}
```

**Operaatiot:**
- Create / Save / Load / Delete
- Add message
- Switch model
- Export (backup)

---

## Black Box -moduulit

```
┌─────────────────────────────────────────────────────────────────────┐
│                    BLACK BOX -MODUULIKARTTA                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    APPLICATION LAYER                         │   │
│  │              (käyttää moduuleja, ei tunne sisäisiä)         │   │
│  │                                                              │   │
│  │  ┌───────────┐  ┌───────────┐  ┌───────────┐               │   │
│  │  │  Web UI   │  │WebSocket  │  │  REST API │               │   │
│  │  │  (SPA)    │  │ Handler   │  │  Router   │               │   │
│  │  └───────────┘  └───────────┘  └───────────┘               │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│                              ▼                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    CORE / BUSINESS LOGIC                     │   │
│  │              (black box, clean API)                          │   │
│  │                                                              │   │
│  │  ┌───────────────┐  ┌───────────────┐                       │   │
│  │  │    Context    │  │    Session    │                       │   │
│  │  │    Manager    │  │    Service    │                       │   │
│  │  │               │  │               │                       │   │
│  │  │ • get_context │  │ • save        │                       │   │
│  │  │ • add_message │  │ • load        │                       │   │
│  │  │ • summarize   │  │ • list        │                       │   │
│  │  │ • token_count │  │ • delete      │                       │   │
│  │  └───────────────┘  └───────────────┘                       │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                              │                                      │
│                              ▼                                      │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                    PLATFORM LAYER                            │   │
│  │              (wrappaa ulkoiset riippuvuudet)                 │   │
│  │                                                              │   │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │   │
│  │  │    Claude     │  │    Memory     │  │   FileSystem  │   │   │
│  │  │    Service    │  │    Service    │  │    Service    │   │   │
│  │  │   (wrapper)   │  │   (wrapper)   │  │   (wrapper)   │   │   │
│  │  │               │  │               │  │               │   │   │
│  │  │ Wraps:        │  │ Wraps:        │  │ Wraps:        │   │   │
│  │  │ Claude API    │  │ Markdown I/O  │  │ os/pathlib    │   │   │
│  │  └───────────────┘  └───────────────┘  └───────────────┘   │   │
│  │                                                              │   │
│  │  ┌───────────────┐  ┌───────────────┐                       │   │
│  │  │    GitHub     │  │    Database   │                       │   │
│  │  │    Service    │  │    Service    │                       │   │
│  │  │   (wrapper)   │  │   (wrapper)   │                       │   │
│  │  │               │  │               │                       │   │
│  │  │ Wraps:        │  │ Wraps:        │                       │   │
│  │  │ GitHub API    │  │ SQLite/PG     │                       │   │
│  │  └───────────────┘  └───────────────┘                       │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Miksi wrapperit?

| Ulkoinen riippuvuus | Wrapper | Hyöty |
|---------------------|---------|-------|
| Claude API | ClaudeService | Voi vaihtaa malliin, lisätä retry, mockkata |
| Tiedostojärjestelmä | MemoryService | Voi vaihtaa S3:een, lisätä validointia |
| SQLite | DatabaseService | Voi vaihtaa PostgreSQL:ään |
| GitHub API | GitHubService | Voi mockkata testeissä |

> **Kriittinen sääntö:** Älä KOSKAAN kutsu ulkoista API:a suoraan sovelluskoodista. Aina wrapperin kautta.

---

## Järjestelmäarkkitehtuuri

```
┌─────────────────────────────────────────────────────────────────────┐
│                    JÄRJESTELMÄARKKITEHTUURI                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                     KÄYTTÖLIITTYMÄKERROS                       │ │
│  │                                                                │ │
│  │  ┌─────────────────────────────────────────────────────────┐  │ │
│  │  │                    Web UI (SPA)                          │  │ │
│  │  │                                                          │  │ │
│  │  │  ┌───────────┐  ┌───────────┐  ┌───────────┐           │  │ │
│  │  │  │   Chat    │  │  Muisti   │  │ Tiedostot │           │  │ │
│  │  │  │  -ikkuna  │  │  -paneeli │  │ -paneeli  │           │  │ │
│  │  │  └───────────┘  └───────────┘  └───────────┘           │  │ │
│  │  │                                                          │  │ │
│  │  │  ┌───────────┐  ┌───────────┐  ┌───────────┐           │  │ │
│  │  │  │  Token-   │  │  Mallin   │  │  Session- │           │  │ │
│  │  │  │  laskuri  │  │  valinta  │  │  hallinta │           │  │ │
│  │  │  └───────────┘  └───────────┘  └───────────┘           │  │ │
│  │  └─────────────────────────────────────────────────────────┘  │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                              │                                      │
│                              │ WebSocket / REST                     │
│                              ▼                                      │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                       BACKEND-KERROS                           │ │
│  │                                                                │ │
│  │  ┌─────────────────────────────────────────────────────────┐  │ │
│  │  │                 Python / FastAPI                         │  │ │
│  │  │                                                          │  │ │
│  │  │  ┌───────────────┐  ┌───────────────┐                   │  │ │
│  │  │  │  API Router   │  │  WebSocket    │                   │  │ │
│  │  │  │  /api/v1/*    │  │  Handler      │                   │  │ │
│  │  │  └───────────────┘  └───────────────┘                   │  │ │
│  │  │                                                          │  │ │
│  │  │  ┌───────────────┐  ┌───────────────┐                   │  │ │
│  │  │  │  Claude       │  │  Context      │                   │  │ │
│  │  │  │  Service      │  │  Manager      │                   │  │ │
│  │  │  └───────────────┘  └───────────────┘                   │  │ │
│  │  │                                                          │  │ │
│  │  │  ┌───────────────┐  ┌───────────────┐                   │  │ │
│  │  │  │  Memory       │  │  Session      │                   │  │ │
│  │  │  │  Service      │  │  Service      │                   │  │ │
│  │  │  └───────────────┘  └───────────────┘                   │  │ │
│  │  └─────────────────────────────────────────────────────────┘  │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                              │                                      │
│                              ▼                                      │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                     TALLENNUS-KERROS                           │ │
│  │                                                                │ │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐      │ │
│  │  │  Markdown     │  │   SQLite /    │  │  Tiedosto-    │      │ │
│  │  │  Muisti       │  │   PostgreSQL  │  │  järjestelmä  │      │ │
│  │  │  /memory/*    │  │   (sessiot)   │  │  /projects/*  │      │ │
│  │  └───────────────┘  └───────────────┘  └───────────────┘      │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                              │                                      │
│                              ▼                                      │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │                   INTEGRAATIOKERROS                            │ │
│  │                                                                │ │
│  │  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐      │ │
│  │  │  Claude API   │  │    GitHub     │  │ Google Drive  │      │ │
│  │  │  (1M beta)    │  │    API        │  │    API        │      │ │
│  │  └───────────────┘  └───────────────┘  └───────────────┘      │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Komponentit yksityiskohtaisesti

### 1. Claude Service

```
┌─────────────────────────────────────────────────────────────────────┐
│                       CLAUDE SERVICE                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Vastuut:                                                          │
│  • Claude API -kutsujen hallinta                                   │
│  • Mallin valinta (Opus 4.5 / Sonnet 4.5)                         │
│  • Effort-parametrin asetus (Opus)                                 │
│  • 1M beta-headerin lisääminen                                     │
│  • Streaming-vastausten käsittely                                  │
│  • Rate limiting ja retry-logiikka                                 │
│                                                                     │
│  Rajapinta:                                                        │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  async def send_message(                                     │   │
│  │      messages: List[Message],                                │   │
│  │      model: str = "claude-sonnet-4-5-20250514",             │   │
│  │      max_tokens: int = 8192,                                 │   │
│  │      effort: Optional[str] = None,  # low/medium/high       │   │
│  │      stream: bool = True                                     │   │
│  │  ) -> AsyncGenerator[StreamChunk, None]                      │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  Konfiguraatio:                                                    │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  ANTHROPIC_API_KEY: str (env)                                │   │
│  │  MAX_CONTEXT_TOKENS: 1_000_000                               │   │
│  │  BETA_HEADER: "max-tokens-3-5-sonnet-2024-07-15"            │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 2. Context Manager

```
┌─────────────────────────────────────────────────────────────────────┐
│                      CONTEXT MANAGER                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Vastuut:                                                          │
│  • Kontekstin kokoaminen (viestit + muisti + tiedostot)            │
│  • Token-laskenta (tiktoken)                                       │
│  • Kontekstin tiivistäminen tarvittaessa                          │
│  • Prioriteettijärjestys: mitä säilytetään, mitä poistetaan       │
│                                                                     │
│  Tiivistysstrategia:                                               │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  1. Poista vanhat tool call -tulokset (> 10 viestiä sitten) │   │
│  │  2. Tiivistä pitkät vastaukset yhteenvedoiksi               │   │
│  │  3. Siirrä päätökset ulkoiseen muistiin                     │   │
│  │  4. Säilytä: viimeiset 20 viestiä + aktiiviset tiedostot    │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  Rajapinta:                                                        │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  def get_context() -> List[Message]                          │   │
│  │  def add_message(message: Message)                           │   │
│  │  def get_token_count() -> int                                │   │
│  │  def needs_summarization() -> bool                           │   │
│  │  async def summarize_if_needed()                             │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 3. Memory Service

```
┌─────────────────────────────────────────────────────────────────────┐
│                       MEMORY SERVICE                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Vastuut:                                                          │
│  • Ulkoisen muistin luku/kirjoitus                                 │
│  • Markdown-tiedostojen hallinta                                   │
│  • Hakemistorakenteen ylläpito                                     │
│  • Claude-toolien tarjoaminen muistin käyttöön                     │
│                                                                     │
│  Hakemistorakenne:                                                 │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  /memory/                                                    │   │
│  │  ├── decisions/                                              │   │
│  │  │   ├── 2025-11-25_backend_technology.md                   │   │
│  │  │   └── 2025-11-25_database_choice.md                      │   │
│  │  ├── summaries/                                              │   │
│  │  │   └── session_001_summary.md                             │   │
│  │  ├── specs/                                                  │   │
│  │  │   └── SPEC_01_API_Integration.md                         │   │
│  │  └── context/                                                │   │
│  │      └── active_context.json                                │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│  Claude-toolit:                                                    │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  - read_memory(path: str) -> str                             │   │
│  │  - write_memory(path: str, content: str)                     │   │
│  │  - list_memory(directory: str) -> List[str]                  │   │
│  │  - search_memory(query: str) -> List[SearchResult]           │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### 4. Session Service

```
┌─────────────────────────────────────────────────────────────────────┐
│                      SESSION SERVICE                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Vastuut:                                                          │
│  • Sessioiden tallennus ja lataus                                  │
│  • Automaattitallennus (5 min välein)                              │
│  • Sessioiden listaus ja haku                                      │
│  • Projektikohtainen sessioiden hallinta                           │
│                                                                     │
│  Session-rakenne:                                                  │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  {                                                           │   │
│  │    "id": "uuid",                                             │   │
│  │    "project_id": "uuid",                                     │   │
│  │    "name": "SPEC_01 suunnittelu",                           │   │
│  │    "created_at": "2025-11-25T10:00:00Z",                    │   │
│  │    "updated_at": "2025-11-25T12:30:00Z",                    │   │
│  │    "messages": [...],                                        │   │
│  │    "context_files": ["file1.md", "file2.py"],               │   │
│  │    "model": "claude-sonnet-4-5-20250514",                   │   │
│  │    "total_tokens": 45000,                                    │   │
│  │    "total_cost_usd": 0.23                                    │   │
│  │  }                                                           │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Tietovirtakaavio

```
┌─────────────────────────────────────────────────────────────────────┐
│                       TIETOVIRTA: VIESTI                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  1. Käyttäjä kirjoittaa viestin                                    │
│     │                                                               │
│     ▼                                                               │
│  2. Frontend lähettää WebSocketilla                                │
│     │                                                               │
│     ▼                                                               │
│  3. Backend: Context Manager                                       │
│     ├─ Lisää viesti kontekstiin                                    │
│     ├─ Lataa relevantit muistitiedostot                           │
│     ├─ Lataa projektin tiedostot                                   │
│     ├─ Laske tokenimäärä                                           │
│     └─ Tiivistä tarvittaessa                                       │
│     │                                                               │
│     ▼                                                               │
│  4. Backend: Claude Service                                        │
│     ├─ Kokoa API-pyyntö (messages + tools)                         │
│     ├─ Lähetä Claude API:lle (streaming)                           │
│     └─ Vastaanota ja välitä chunkit                                │
│     │                                                               │
│     ▼                                                               │
│  5. Frontend: Renderöi vastaus (streaming)                         │
│     │                                                               │
│     ▼                                                               │
│  6. Backend: Käsittele tool calls (jos on)                         │
│     ├─ read_memory / write_memory                                  │
│     ├─ list_files / read_file                                      │
│     └─ Palauta tulokset Claudelle                                  │
│     │                                                               │
│     ▼                                                               │
│  7. Backend: Tallenna sessio                                       │
│     ├─ Päivitä messages                                            │
│     ├─ Päivitä token-laskuri                                       │
│     └─ Automaattitallennus tietokantaan                            │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Teknologiavalinnat

### Vahvistetut

| Komponentti | Teknologia | Perustelu |
|-------------|------------|-----------|
| **Backend-kieli** | Python 3.11+ | Anthropic SDK, hyvä AI-ekosysteemi |
| **Backend-framework** | FastAPI | Async, WebSocket-tuki, OpenAPI |
| **AI API** | Claude API | Projektin ydin |

### Arvioitavana

| Komponentti | Vaihtoehdot | Suositus | Päätös |
|-------------|-------------|----------|--------|
| **Frontend** | React, Vue, Svelte | Svelte (kevyt, nopea) | 🔲 |
| **Tietokanta** | SQLite, PostgreSQL | SQLite (MVP), PostgreSQL (tuotanto) | 🔲 |
| **Hosting** | Local, VPS (Hetzner), Cloud | Local (MVP), VPS (tuotanto) | 🔲 |
| **Token-laskenta** | tiktoken, Anthropic API | tiktoken (nopea, offline) | 🔲 |

---

## API-rakenne

### REST Endpoints

```
GET  /api/v1/sessions              - Listaa sessiot
POST /api/v1/sessions              - Luo uusi sessio
GET  /api/v1/sessions/{id}         - Hae sessio
PUT  /api/v1/sessions/{id}         - Päivitä sessio
DEL  /api/v1/sessions/{id}         - Poista sessio

GET  /api/v1/memory                - Listaa muistitiedostot
GET  /api/v1/memory/{path}         - Lue muistitiedosto
PUT  /api/v1/memory/{path}         - Kirjoita muistitiedosto
DEL  /api/v1/memory/{path}         - Poista muistitiedosto

GET  /api/v1/files                 - Listaa projektin tiedostot
POST /api/v1/files                 - Upload tiedosto
GET  /api/v1/files/{path}          - Lue tiedosto
DEL  /api/v1/files/{path}          - Poista tiedosto

GET  /api/v1/stats                 - Token-tilastot, kustannukset
```

### WebSocket

```
WS /api/v1/chat/{session_id}

Client -> Server:
{
  "type": "message",
  "content": "Käyttäjän viesti"
}

Server -> Client:
{
  "type": "chunk",
  "content": "Clauden vastauksen osa..."
}

{
  "type": "tool_call",
  "tool": "read_memory",
  "input": {"path": "decisions/backend.md"}
}

{
  "type": "done",
  "tokens_used": 1234,
  "cost_usd": 0.01
}
```

---

## Turvallisuus

### API-avaimen hallinta

```
┌─────────────────────────────────────────────────────────────────────┐
│                    API-AVAIMEN HALLINTA                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Kehitys (local):                                                  │
│  • .env tiedosto (ei versionhallintaan!)                          │
│  • ANTHROPIC_API_KEY=sk-ant-...                                    │
│                                                                     │
│  Tuotanto:                                                         │
│  • Ympäristömuuttuja serverillä                                    │
│  • TAI: Secrets manager (AWS, GCP, Vault)                          │
│                                                                     │
│  Ei koskaan:                                                       │
│  • Koodiin kovakoodattuna                                          │
│  • Git-repositorioon                                               │
│  • Frontendiin (vain backend käyttää)                              │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Autentikointi (MVP)

```
MVP: Yksinkertainen (yksi käyttäjä, local)
• Ei autentikointia MVP:ssä
• Vain localhost-käyttö

Myöhemmin:
• HTTP Basic Auth (yksinkertainen)
• TAI: JWT tokens (monipuolisempi)
```

---

## Kehitysympäristö

### Hakemistorakenne

```
claude-planning-tool/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py              # FastAPI app
│   │   ├── config.py            # Konfiguraatio
│   │   ├── routers/
│   │   │   ├── chat.py          # WebSocket
│   │   │   ├── sessions.py      # REST
│   │   │   ├── memory.py        # REST
│   │   │   └── files.py         # REST
│   │   ├── services/            # PLATFORM LAYER (wrappers)
│   │   │   ├── claude.py        # Claude API wrapper
│   │   │   ├── memory.py        # Markdown I/O wrapper
│   │   │   ├── database.py      # SQLite/PG wrapper
│   │   │   └── github.py        # GitHub API wrapper
│   │   ├── core/                # BUSINESS LOGIC
│   │   │   ├── context.py       # Kontekstin hallinta
│   │   │   └── session.py       # Sessioiden hallinta
│   │   └── models/              # PRIMITIVES
│   │       ├── message.py       # Message-primitiivi
│   │       ├── memory_item.py   # MemoryItem-primitiivi
│   │       └── session.py       # Session-primitiivi
│   ├── tests/
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/
│   ├── src/
│   ├── package.json
│   └── Dockerfile
├── memory/                       # Ulkoinen muisti
│   ├── decisions/
│   ├── summaries/
│   └── specs/
├── projects/                     # Käyttäjän projektit
├── docker-compose.yml
├── .env.example
└── README.md
```

---

## Architecture Analysis Checklist

> Perustuu systems-architecture skilliin. Käy läpi ennen isoja päätöksiä.

### Primitiivit
- [x] **Primitiivit tunnistettu?** Message, MemoryItem, Session
- [x] **Yksinkertaisia?** Kyllä, helppo ymmärtää
- [x] **Universaaleja?** Kaikki data mahtuu näihin
- [x] **Tulevaisuudenkestäviä?** Kyllä, laajennettavissa

### Black Box -moduulit
- [x] **Rajat selkeät?** Core / Platform / Application
- [x] **APIt dokumentoitu?** Kyllä, tässä dokumentissa
- [ ] **Voidaanko kirjoittaa uudelleen?** Testattava toteutuksessa
- [x] **Yksi omistaja per moduuli?** Kyllä, yksi kehittäjä

### Riippuvuudet
- [x] **Ulkoiset wrapatttu?** Claude, Memory, GitHub, Database
- [x] **Ei suoria kutsuja?** Vain wrappereiden kautta
- [x] **Voidaanko vaihtaa?** Kyllä, wrapper piilottaa toteutuksen

### Riskit
- [ ] **Platform risk?** Claude API voi muuttua → wrapper suojaa
- [ ] **Scale risk?** 10x käyttäjiä? → Ei vielä relevantti (MVP)
- [ ] **Team risk?** Yksi kehittäjä → OK MVP:lle

### Työkalut (suunniteltava)
- [ ] **Test app?** Yksinkertainen CLI testaukseen
- [ ] **Logger?** Strukturoitu lokitus
- [ ] **Mock/Stub?** Claude API:n mockaus testeissä

---

## Muutoshistoria

| Versio | Päivämäärä | Muutokset |
|--------|------------|-----------|
| 1.1 | 2025-11-25 | Lisätty primitiivit, black box -moduulit, analysis checklist (systems-architecture skill) |
| 1.0 | 2025-11-25 | Ensimmäinen versio |

---

*Dokumentti on osa Claude API -suunnittelutyökalun dokumentaatiota.*
